import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CheckCircle2, Circle, Clock, Trophy, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export type DifficultyLevel = "easy" | "medium" | "hard";

export interface Task {
  id: string;
  title: string;
  description: string;
  difficulty: DifficultyLevel;
  estimatedTime: string;
  resourceLink: string;
  resourceTitle: string;
  proofOfWork: string;
  completed: boolean;
  week: number;
  day: number;
}

interface TaskCardProps {
  task: Task;
  onToggleComplete: (taskId: string) => void;
}

const difficultyConfig = {
  easy: {
    label: "Easy",
    className: "badge-easy",
    icon: "🌱",
  },
  medium: {
    label: "Medium",
    className: "badge-medium",
    icon: "⚡",
  },
  hard: {
    label: "Hard",
    className: "badge-hard",
    icon: "🔥",
  },
};

export function TaskCard({ task, onToggleComplete }: TaskCardProps) {
  const navigate = useNavigate();
  const [isExpanded, setIsExpanded] = useState(false);
  const diffConfig = difficultyConfig[task.difficulty];

  const handleTakeCourse = () => {
    navigate(`/lesson/${task.id}`);
  };

  return (
    <div
      className={`glass-card rounded-xl p-4 md:p-5 transition-all duration-300 ${
        task.completed ? "opacity-75" : ""
      }`}
    >
      <div className="flex items-start gap-4">
        {/* Completion toggle */}
        <button
          onClick={() => onToggleComplete(task.id)}
          className="mt-0.5 flex-shrink-0 focus-ring rounded-full"
          aria-label={task.completed ? "Mark as incomplete" : "Mark as complete"}
        >
          {task.completed ? (
            <CheckCircle2 className="w-6 h-6 text-success" />
          ) : (
            <Circle className="w-6 h-6 text-muted-foreground hover:text-primary transition-colors" />
          )}
        </button>

        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-start justify-between gap-3 mb-2">
            <h4
              className={`font-semibold text-foreground ${
                task.completed ? "line-through text-muted-foreground" : ""
              }`}
            >
              {task.title}
            </h4>
            <span className={`flex-shrink-0 px-2.5 py-1 rounded-full text-xs font-medium ${diffConfig.className}`}>
              {diffConfig.icon} {diffConfig.label}
            </span>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {task.description}
          </p>

          {/* Meta info */}
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <Clock className="w-4 h-4" />
              {task.estimatedTime}
            </span>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleTakeCourse}
              className="text-primary hover:text-primary/80 p-0 h-auto font-normal"
            >
              <PlayCircle className="w-4 h-4 mr-1.5" />
              Take Course
            </Button>
          </div>

          {/* Expandable Proof of Work */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="mt-3 text-sm font-medium text-accent-foreground flex items-center gap-1.5 hover:text-primary transition-colors"
          >
            <Trophy className="w-4 h-4" />
            Proof of Work Assignment
          </button>
          
          {isExpanded && (
            <div className="mt-3 p-3 rounded-lg bg-accent/50 border border-accent animate-fade-in">
              <p className="text-sm text-foreground">{task.proofOfWork}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}