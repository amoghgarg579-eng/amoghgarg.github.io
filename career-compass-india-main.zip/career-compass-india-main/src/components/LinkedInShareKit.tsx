import { useState } from "react";
import { Linkedin, Download, Share2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

interface LinkedInShareKitProps {
  readinessScore: number;
  targetRole: string;
  completedTasks: number;
  totalTasks: number;
}

export function LinkedInShareKit({
  readinessScore,
  targetRole,
  completedTasks,
  totalTasks,
}: LinkedInShareKitProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateShareText = () => {
    const emoji = readinessScore >= 80 ? "🚀" : readinessScore >= 50 ? "⚡" : "🌱";
    
    return `${emoji} Career Pivot Update: ${readinessScore}% Ready for ${targetRole}!

I've completed ${completedTasks}/${totalTasks} tasks on my journey to transition into tech.

Key highlights:
• Building real projects with proof-of-work assignments
• Learning from curated resources
• Following a structured 30-day roadmap

The "Tier-2/3 college" narrative is changing. Skills > Degrees.

#CareerPivot #TechCareers #Learning #PivotPath #IndiaInTech`;
  };

  const handleShare = async () => {
    const shareText = encodeURIComponent(generateShareText());
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent("https://pivotpath.in")}&summary=${shareText}`;
    window.open(linkedInUrl, "_blank", "width=600,height=600");
  };

  const handleGenerateImage = async () => {
    setIsGenerating(true);
    // Simulate image generation
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsGenerating(false);
    // In production, this would generate an actual image
  };

  return (
    <div className="glass-card rounded-2xl p-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#0A66C2]/10 flex items-center justify-center">
          <Linkedin className="w-5 h-5 text-[#0A66C2]" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground">LinkedIn Viral Kit</h3>
          <p className="text-sm text-muted-foreground">Share your progress</p>
        </div>
      </div>

      {/* Preview card */}
      <div className="p-4 rounded-xl bg-gradient-to-br from-primary/5 to-primary/10 border border-primary/20">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-medium text-muted-foreground">Preview</span>
          <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">
            Auto-generated
          </span>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm font-bold">
              {readinessScore}%
            </div>
            <span className="font-semibold text-foreground">{targetRole}</span>
          </div>
          
          <p className="text-sm text-muted-foreground line-clamp-3">
            {generateShareText().split("\n\n")[0]}
          </p>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Button
          onClick={handleGenerateImage}
          variant="outline"
          className="flex-1 gap-2"
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <Sparkles className="w-4 h-4 animate-pulse" />
              Generating...
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              Download Image
            </>
          )}
        </Button>
        
        <Button
          onClick={handleShare}
          className="flex-1 gap-2 btn-gradient text-primary-foreground border-0"
        >
          <Share2 className="w-4 h-4" />
          Share on LinkedIn
        </Button>
      </div>
    </div>
  );
}