import { useState, useCallback } from "react";
import { Upload, FileText, CheckCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ResumeDropzoneProps {
  onFileUpload: (file: File) => void;
}

export function ResumeDropzone({ onFileUpload }: ResumeDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDragIn = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragging(true);
    }
  }, []);

  const handleDragOut = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type === "application/pdf" || file.name.endsWith(".pdf")) {
        setUploadedFile(file);
        onFileUpload(file);
      }
    }
  }, [onFileUpload]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setUploadedFile(file);
      onFileUpload(file);
    }
  }, [onFileUpload]);

  const removeFile = useCallback(() => {
    setUploadedFile(null);
  }, []);

  if (uploadedFile) {
    return (
      <div className="glass-card rounded-2xl p-6 animate-scale-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary-muted flex items-center justify-center">
              <FileText className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="font-medium text-foreground">{uploadedFile.name}</p>
              <p className="text-sm text-muted-foreground">
                {(uploadedFile.size / 1024).toFixed(1)} KB
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-success">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm font-medium">Uploaded</span>
            </div>
            <button
              onClick={removeFile}
              className="p-2 rounded-lg hover:bg-muted transition-colors"
              aria-label="Remove file"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`dropzone rounded-2xl p-8 md:p-12 text-center cursor-pointer transition-all ${
        isDragging ? "active" : ""
      }`}
      onDragEnter={handleDragIn}
      onDragLeave={handleDragOut}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      onClick={() => document.getElementById("resume-input")?.click()}
    >
      <input
        id="resume-input"
        type="file"
        accept=".pdf"
        className="hidden"
        onChange={handleFileInput}
      />
      
      <div className="flex flex-col items-center gap-4">
        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-colors ${
          isDragging ? "bg-primary text-primary-foreground" : "bg-primary-muted"
        }`}>
          <Upload className={`w-8 h-8 ${isDragging ? "text-primary-foreground" : "text-primary"}`} />
        </div>
        
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-1">
            {isDragging ? "Drop your resume here" : "Upload Your Resume"}
          </h3>
          <p className="text-muted-foreground text-sm">
            Drag & drop your PDF resume, or{" "}
            <span className="text-primary font-medium">click to browse</span>
          </p>
        </div>
        
        <Button variant="outline" size="sm" className="mt-2">
          Select PDF File
        </Button>
      </div>
    </div>
  );
}