import { Brain, Code, Database, Shield, TrendingUp, Sparkles } from "lucide-react";

interface TargetRole {
  id: string;
  title: string;
  salary: string;
  demand: string;
  icon: React.ReactNode;
}

const targetRoles: TargetRole[] = [
  {
    id: "ml-engineer",
    title: "ML Engineer",
    salary: "15-30 LPA",
    demand: "Very High",
    icon: <Brain className="w-5 h-5" />,
  },
  {
    id: "fullstack-dev",
    title: "Full Stack Developer",
    salary: "12-25 LPA",
    demand: "High",
    icon: <Code className="w-5 h-5" />,
  },
  {
    id: "data-engineer",
    title: "Data Engineer",
    salary: "14-28 LPA",
    demand: "Very High",
    icon: <Database className="w-5 h-5" />,
  },
  {
    id: "devops-engineer",
    title: "DevOps Engineer",
    salary: "12-24 LPA",
    demand: "High",
    icon: <TrendingUp className="w-5 h-5" />,
  },
  {
    id: "security-engineer",
    title: "Security Engineer",
    salary: "15-30 LPA",
    demand: "Very High",
    icon: <Shield className="w-5 h-5" />,
  },
  {
    id: "ai-product-manager",
    title: "AI Product Manager",
    salary: "18-35 LPA",
    demand: "High",
    icon: <Sparkles className="w-5 h-5" />,
  },
];

interface TargetRoleSelectorProps {
  selectedRole: string | null;
  onSelectRole: (roleId: string) => void;
}

export function TargetRoleSelector({ selectedRole, onSelectRole }: TargetRoleSelectorProps) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-foreground mb-1">Select Your Target Role</h3>
        <p className="text-sm text-muted-foreground">
          Choose the 2026 tech role you want to pivot into
        </p>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {targetRoles.map((role) => (
          <button
            key={role.id}
            onClick={() => onSelectRole(role.id)}
            className={`p-4 rounded-xl text-left transition-all focus-ring ${
              selectedRole === role.id
                ? "glass-card border-primary bg-primary-muted"
                : "bg-card border border-border hover:border-primary/50"
            }`}
          >
            <div className="flex items-start gap-3">
              <div
                className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  selectedRole === role.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {role.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-foreground text-sm truncate">
                  {role.title}
                </h4>
                <p className="text-xs text-muted-foreground">{role.salary}</p>
                <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium bg-success/10 text-success">
                  {role.demand}
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}