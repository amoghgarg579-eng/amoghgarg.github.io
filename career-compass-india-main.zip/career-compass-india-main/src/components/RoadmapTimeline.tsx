import { TaskCard, Task } from "./TaskCard";

interface RoadmapTimelineProps {
  tasks: Task[];
  onToggleComplete: (taskId: string) => void;
}

interface WeekGroup {
  week: number;
  tasks: Task[];
  completedCount: number;
}

export function RoadmapTimeline({ tasks, onToggleComplete }: RoadmapTimelineProps) {
  // Group tasks by week
  const weekGroups: WeekGroup[] = [1, 2, 3, 4].map((week) => {
    const weekTasks = tasks.filter((t) => t.week === week);
    return {
      week,
      tasks: weekTasks,
      completedCount: weekTasks.filter((t) => t.completed).length,
    };
  });

  const weekLabels = [
    { week: 1, title: "Foundation", subtitle: "Core Skills Setup" },
    { week: 2, title: "Deep Dive", subtitle: "Technical Mastery" },
    { week: 3, title: "Build", subtitle: "Project Development" },
    { week: 4, title: "Launch", subtitle: "Interview Ready" },
  ];

  return (
    <div className="relative">
      {weekGroups.map((group, groupIndex) => {
        const label = weekLabels[groupIndex];
        const isComplete = group.completedCount === group.tasks.length && group.tasks.length > 0;
        
        return (
          <div key={group.week} className="relative pb-8 last:pb-0">
            {/* Timeline connector */}
            {groupIndex < weekGroups.length - 1 && (
              <div className="absolute left-[19px] top-12 w-0.5 h-[calc(100%-48px)] timeline-line opacity-30" />
            )}
            
            {/* Week header */}
            <div className="flex items-center gap-4 mb-4">
              <div
                className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-colors ${
                  isComplete
                    ? "bg-success text-success-foreground"
                    : "bg-primary text-primary-foreground"
                }`}
              >
                W{group.week}
              </div>
              
              <div>
                <h3 className="font-bold text-lg text-foreground">{label.title}</h3>
                <p className="text-sm text-muted-foreground">{label.subtitle}</p>
              </div>
              
              <div className="ml-auto">
                <span className="text-sm font-medium text-muted-foreground">
                  {group.completedCount}/{group.tasks.length} tasks
                </span>
              </div>
            </div>
            
            {/* Tasks grid */}
            <div className="ml-14 space-y-3">
              {group.tasks.map((task, index) => (
                <div
                  key={task.id}
                  className="animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <TaskCard task={task} onToggleComplete={onToggleComplete} />
                </div>
              ))}
              
              {group.tasks.length === 0 && (
                <div className="glass-card rounded-xl p-6 text-center">
                  <p className="text-muted-foreground">
                    Upload your resume to generate personalized tasks for Week {group.week}
                  </p>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}