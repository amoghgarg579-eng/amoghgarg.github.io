import { useState, useEffect } from "react";
import { CheckCircle2, XCircle, HelpCircle, Trophy, ArrowRight, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { QuizQuestion } from "@/data/lessonContent";
import { toast } from "sonner";

interface LessonQuizProps {
  questions: QuizQuestion[];
  onComplete: (passed: boolean, score: number) => void;
  lessonTitle?: string;
  lessonContent?: string;
}

export function LessonQuiz({ questions: initialQuestions, onComplete, lessonTitle, lessonContent }: LessonQuizProps) {
  const [questions, setQuestions] = useState<QuizQuestion[]>(initialQuestions);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | undefined>(undefined);
  const [showResult, setShowResult] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [isGenerating, setIsGenerating] = useState(false);

  // Reset state when questions change
  useEffect(() => {
    setCurrentQuestion(0);
    setSelectedAnswer(undefined);
    setShowResult(false);
    setIsSubmitted(false);
    setAnswers({});
  }, [questions]);

  const question = questions[currentQuestion];
  const isCorrect = selectedAnswer === question?.correctAnswer;
  const isLastQuestion = currentQuestion === questions.length - 1;

  const generateAIQuestions = async () => {
    if (!lessonTitle || !lessonContent) {
      toast.error("Lesson content not available for AI generation");
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-quiz`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            lessonTitle,
            lessonContent,
            questionCount: 5
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "Failed to generate questions");
      }

      const data = await response.json();
      if (data.questions && data.questions.length > 0) {
        // Map AI response to our QuizQuestion format
        const mappedQuestions: QuizQuestion[] = data.questions.map((q: any, index: number) => ({
          id: q.id || `ai-${index}`,
          question: q.question,
          options: q.options,
          correctAnswer: q.correctIndex,
          explanation: q.explanation
        }));
        setQuestions(mappedQuestions);
        toast.success("New AI-generated questions loaded!");
      }
    } catch (error) {
      console.error("Error generating quiz:", error);
      toast.error(error instanceof Error ? error.message : "Failed to generate questions");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAnswerSelect = (value: string) => {
    if (isSubmitted) return;
    // Clear previous selection and set new one
    setSelectedAnswer(parseInt(value));
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === undefined) return;
    setIsSubmitted(true);
    setAnswers(prev => ({
      ...prev,
      [question.id]: selectedAnswer
    }));
  };

  const handleNextQuestion = () => {
    if (isLastQuestion) {
      // Calculate final score using stored answers plus current
      const allAnswers = { ...answers, [question.id]: selectedAnswer };
      const correctCount = questions.filter(
        q => allAnswers[q.id] === q.correctAnswer
      ).length;
      const score = Math.round((correctCount / questions.length) * 100);
      const passed = score >= 67;
      setShowResult(true);
      onComplete(passed, score);
    } else {
      setCurrentQuestion(prev => prev + 1);
      setIsSubmitted(false);
      setSelectedAnswer(undefined);
    }
  };

  const handleRetry = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(undefined);
    setShowResult(false);
    setIsSubmitted(false);
    setAnswers({});
  };

  if (showResult) {
    const allAnswers = { ...answers, [question?.id]: selectedAnswer };
    const correctCount = questions.filter(
      q => allAnswers[q.id] === q.correctAnswer
    ).length;
    const score = Math.round((correctCount / questions.length) * 100);
    const passed = score >= 67;

    return (
      <div className="text-center py-8">
        <div className={`w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center ${
          passed ? "bg-success/10" : "bg-destructive/10"
        }`}>
          {passed ? (
            <Trophy className="w-10 h-10 text-success" />
          ) : (
            <XCircle className="w-10 h-10 text-destructive" />
          )}
        </div>
        
        <h3 className={`text-2xl font-bold mb-2 ${passed ? "text-success" : "text-destructive"}`}>
          {passed ? "Congratulations!" : "Keep Learning!"}
        </h3>
        
        <p className="text-muted-foreground mb-4">
          You scored {correctCount} out of {questions.length} ({score}%)
        </p>
        
        {passed ? (
          <p className="text-foreground mb-6">
            You've unlocked the next lesson. Great job! 🎉
          </p>
        ) : (
          <p className="text-foreground mb-6">
            Review the material and try again. You need 67% to proceed.
          </p>
        )}

        <div className="flex justify-center gap-3">
          <Button onClick={handleRetry} variant="outline">
            Try Again
          </Button>
          {lessonTitle && lessonContent && (
            <Button onClick={generateAIQuestions} disabled={isGenerating} className="gap-2">
              {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              New Questions
            </Button>
          )}
        </div>
      </div>
    );
  }

  if (!question) {
    return <div className="text-center py-8 text-muted-foreground">No questions available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header with AI generate button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {questions.map((_, index) => (
            <div
              key={index}
              className={`h-2 w-8 rounded-full transition-colors ${
                index < currentQuestion
                  ? "bg-success"
                  : index === currentQuestion
                  ? "bg-primary"
                  : "bg-muted"
              }`}
            />
          ))}
        </div>
        {lessonTitle && lessonContent && (
          <Button
            variant="ghost"
            size="sm"
            onClick={generateAIQuestions}
            disabled={isGenerating}
            className="gap-2 text-xs"
          >
            {isGenerating ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <RefreshCw className="w-3 h-3" />
            )}
            Generate New
          </Button>
        )}
      </div>

      {/* Question */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <HelpCircle className="w-5 h-5 text-primary" />
          <span className="text-sm font-medium text-muted-foreground">
            Question {currentQuestion + 1} of {questions.length}
          </span>
        </div>
        
        <h4 className="text-lg font-semibold text-foreground mb-4">
          {question.question}
        </h4>
      </div>

      {/* Options */}
      <RadioGroup
        value={selectedAnswer?.toString()}
        onValueChange={handleAnswerSelect}
        className="space-y-3"
      >
        {question.options.map((option, index) => {
          const isSelected = selectedAnswer === index;
          const showCorrect = isSubmitted && index === question.correctAnswer;
          const showIncorrect = isSubmitted && isSelected && !isCorrect;

          return (
            <div
              key={index}
              onClick={() => !isSubmitted && handleAnswerSelect(index.toString())}
              className={`flex items-center space-x-3 p-4 rounded-lg border transition-all ${
                showCorrect
                  ? "border-success bg-success/5"
                  : showIncorrect
                  ? "border-destructive bg-destructive/5"
                  : isSelected
                  ? "border-primary bg-primary/5"
                  : "border-border bg-background hover:border-primary/50"
              } ${isSubmitted ? "pointer-events-none" : "cursor-pointer"}`}
            >
              <RadioGroupItem
                value={index.toString()}
                id={`option-${question.id}-${index}`}
                disabled={isSubmitted}
                checked={isSelected}
              />
              <Label
                htmlFor={`option-${question.id}-${index}`}
                className={`flex-1 cursor-pointer ${isSubmitted ? "cursor-default" : ""}`}
              >
                {option}
              </Label>
              
              {showCorrect && (
                <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0" />
              )}
              {showIncorrect && (
                <XCircle className="w-5 h-5 text-destructive flex-shrink-0" />
              )}
            </div>
          );
        })}
      </RadioGroup>

      {/* Explanation after submission */}
      {isSubmitted && question.explanation && (
        <div className="p-4 rounded-lg bg-muted/50 border border-border">
          <p className="text-sm text-muted-foreground">
            <strong className="text-foreground">Explanation:</strong> {question.explanation}
          </p>
        </div>
      )}

      {/* Action button */}
      <div className="pt-4">
        {!isSubmitted ? (
          <Button
            onClick={handleSubmitAnswer}
            disabled={selectedAnswer === undefined}
            className="w-full"
          >
            Check Answer
          </Button>
        ) : (
          <Button onClick={handleNextQuestion} className="w-full">
            {isLastQuestion ? "See Results" : "Next Question"}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        )}
      </div>
    </div>
  );
}
