import { ArrowRight, Sparkles, TrendingUp, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ResumeDropzone } from "./ResumeDropzone";
import heroPattern from "@/assets/hero-pattern.jpg";

interface HeroSectionProps {
  onFileUpload: (file: File) => void;
  onGetStarted: () => void;
}

export function HeroSection({ onFileUpload, onGetStarted }: HeroSectionProps) {
  return (
    <section className="relative min-h-[90vh] flex flex-col items-center justify-center px-4 py-16 md:py-24 overflow-hidden">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: `url(${heroPattern})` }}
      />
      <div className="absolute inset-0 hero-gradient" />
      
      <div className="relative z-10 max-w-4xl mx-auto text-center space-y-8 animate-fade-in">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-muted border border-primary/20">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">
            AI-Powered Career Transition
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
          Pivot to a{" "}
          <span className="text-gradient">15 LPA Role</span>
          <br />
          in 30 Days
        </h1>

        {/* Subheadline */}
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          AI analyzes your resume, maps your skills to 2026's hottest tech roles, 
          and creates a personalized roadmap. No degree requirements—just skills.
        </p>

        {/* Stats */}
        <div className="flex flex-wrap justify-center gap-6 md:gap-10 py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-success/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-success" />
            </div>
            <div className="text-left">
              <p className="font-bold text-foreground">500+</p>
              <p className="text-xs text-muted-foreground">Successful Pivots</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div className="text-left">
              <p className="font-bold text-foreground">Tier 2/3</p>
              <p className="text-xs text-muted-foreground">College Friendly</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-warning/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-warning" />
            </div>
            <div className="text-left">
              <p className="font-bold text-foreground">AI-Curated</p>
              <p className="text-xs text-muted-foreground">Roadmaps</p>
            </div>
          </div>
        </div>

        {/* Resume Dropzone */}
        <div className="max-w-lg mx-auto w-full">
          <ResumeDropzone onFileUpload={onFileUpload} />
        </div>

        {/* CTA */}
        <div className="pt-4">
          <Button
            onClick={onGetStarted}
            size="lg"
            className="btn-gradient text-primary-foreground border-0 px-8 py-6 text-lg font-semibold gap-2"
          >
            Start Your Pivot
            <ArrowRight className="w-5 h-5" />
          </Button>
        </div>

        {/* Trust badges */}
        <p className="text-sm text-muted-foreground">
          ✨ Free to start • No credit card required • Works on mobile
        </p>
      </div>
    </section>
  );
}