import { useMemo } from "react";

interface ProgressGaugeProps {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  showLabel?: boolean;
}

export function ProgressGauge({
  percentage,
  size = 180,
  strokeWidth = 12,
  showLabel = true,
}: ProgressGaugeProps) {
  const normalizedPercentage = Math.min(100, Math.max(0, percentage));
  
  const { circumference, strokeDashoffset, radius } = useMemo(() => {
    const r = (size - strokeWidth) / 2;
    const c = 2 * Math.PI * r;
    const offset = c - (normalizedPercentage / 100) * c;
    return { circumference: c, strokeDashoffset: offset, radius: r };
  }, [size, strokeWidth, normalizedPercentage]);

  const getColor = () => {
    if (normalizedPercentage >= 80) return "hsl(var(--success))";
    if (normalizedPercentage >= 50) return "hsl(var(--warning))";
    return "hsl(var(--primary))";
  };

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg
        width={size}
        height={size}
        className="progress-ring"
      >
        {/* Background track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="hsl(var(--progress-track))"
          strokeWidth={strokeWidth}
        />
        
        {/* Progress arc */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={getColor()}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          style={{
            transition: "stroke-dashoffset 0.5s ease-out, stroke 0.3s ease",
          }}
        />
      </svg>
      
      {showLabel && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span 
            className="text-4xl font-bold"
            style={{ color: getColor() }}
          >
            {Math.round(normalizedPercentage)}%
          </span>
          <span className="text-sm text-muted-foreground font-medium mt-1">
            Job Ready
          </span>
        </div>
      )}
    </div>
  );
}