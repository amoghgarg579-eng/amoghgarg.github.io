import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { RoadmapTimeline } from "@/components/RoadmapTimeline";
import { ProgressGauge } from "@/components/ProgressGauge";
import { LinkedInShareKit } from "@/components/LinkedInShareKit";
import { Task } from "@/components/TaskCard";
import { ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

// Sample tasks data - in production this would come from AI analysis
const generateSampleTasks = (roleId: string): Task[] => {
  const roleTasks: Record<string, Task[]> = {
    "ml-engineer": [
      // Week 1
      {
        id: "1-1",
        title: "Python Fundamentals Refresher",
        description: "Master Python basics including data structures, functions, and OOP concepts essential for ML",
        difficulty: "easy",
        estimatedTime: "4 hours",
        resourceLink: "https://youtube.com/watch?v=python-crash-course",
        resourceTitle: "Python Crash Course",
        proofOfWork: "Build a CLI tool that processes a CSV file and outputs statistics (mean, median, mode)",
        completed: false,
        week: 1,
        day: 1,
      },
      {
        id: "1-2",
        title: "NumPy & Pandas Deep Dive",
        description: "Learn data manipulation with NumPy arrays and Pandas DataFrames",
        difficulty: "medium",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=numpy-pandas-tutorial",
        resourceTitle: "NumPy & Pandas Tutorial",
        proofOfWork: "Analyze a Kaggle dataset and create 5 insights using Pandas",
        completed: false,
        week: 1,
        day: 2,
      },
      {
        id: "1-3",
        title: "Statistics for ML",
        description: "Understand probability, distributions, and statistical tests",
        difficulty: "medium",
        estimatedTime: "5 hours",
        resourceLink: "https://youtube.com/watch?v=statistics-ml",
        resourceTitle: "Statistics for Data Science",
        proofOfWork: "Perform hypothesis testing on a real dataset and document findings",
        completed: false,
        week: 1,
        day: 4,
      },
      // Week 2
      {
        id: "2-1",
        title: "Linear Algebra Essentials",
        description: "Learn vectors, matrices, and transformations crucial for understanding ML algorithms",
        difficulty: "hard",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=3blue1brown-linear-algebra",
        resourceTitle: "3Blue1Brown Linear Algebra",
        proofOfWork: "Implement matrix operations from scratch in Python without NumPy",
        completed: false,
        week: 2,
        day: 1,
      },
      {
        id: "2-2",
        title: "Scikit-Learn Fundamentals",
        description: "Master the most popular ML library for classical algorithms",
        difficulty: "medium",
        estimatedTime: "5 hours",
        resourceLink: "https://youtube.com/watch?v=sklearn-tutorial",
        resourceTitle: "Scikit-Learn Complete Guide",
        proofOfWork: "Build a complete ML pipeline with preprocessing, training, and evaluation",
        completed: false,
        week: 2,
        day: 3,
      },
      {
        id: "2-3",
        title: "Classification Algorithms",
        description: "Understand Decision Trees, Random Forests, and ensemble methods",
        difficulty: "medium",
        estimatedTime: "4 hours",
        resourceLink: "https://youtube.com/watch?v=classification-ml",
        resourceTitle: "Classification Deep Dive",
        proofOfWork: "Build a spam classifier with 90%+ accuracy on a public dataset",
        completed: false,
        week: 2,
        day: 5,
      },
      // Week 3
      {
        id: "3-1",
        title: "Deep Learning with PyTorch",
        description: "Introduction to neural networks and PyTorch framework",
        difficulty: "hard",
        estimatedTime: "8 hours",
        resourceLink: "https://youtube.com/watch?v=pytorch-tutorial",
        resourceTitle: "PyTorch for Beginners",
        proofOfWork: "Build and train a neural network for MNIST digit classification",
        completed: false,
        week: 3,
        day: 1,
      },
      {
        id: "3-2",
        title: "CNNs for Computer Vision",
        description: "Learn convolutional neural networks for image processing",
        difficulty: "hard",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=cnn-tutorial",
        resourceTitle: "CNNs Explained",
        proofOfWork: "Build an image classifier that can distinguish between 5 categories",
        completed: false,
        week: 3,
        day: 3,
      },
      // Week 4
      {
        id: "4-1",
        title: "Model Deployment Basics",
        description: "Learn to deploy ML models using FastAPI and Docker",
        difficulty: "medium",
        estimatedTime: "5 hours",
        resourceLink: "https://youtube.com/watch?v=ml-deployment",
        resourceTitle: "ML Model Deployment",
        proofOfWork: "Deploy your best model as a REST API and host it on Railway/Render",
        completed: false,
        week: 4,
        day: 1,
      },
      {
        id: "4-2",
        title: "ML System Design",
        description: "Prepare for ML system design interviews with common patterns",
        difficulty: "hard",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=ml-system-design",
        resourceTitle: "ML System Design Interview",
        proofOfWork: "Write a system design document for a recommendation system",
        completed: false,
        week: 4,
        day: 3,
      },
      {
        id: "4-3",
        title: "Interview Preparation",
        description: "Practice ML coding interviews and behavioral questions",
        difficulty: "medium",
        estimatedTime: "4 hours",
        resourceLink: "https://youtube.com/watch?v=ml-interview-prep",
        resourceTitle: "ML Interview Guide",
        proofOfWork: "Complete 10 LeetCode ML-specific problems and record solutions",
        completed: false,
        week: 4,
        day: 5,
      },
    ],
    "fullstack-dev": [
      // Week 1
      {
        id: "1-1",
        title: "HTML & CSS Mastery",
        description: "Build responsive layouts with modern CSS including Flexbox and Grid",
        difficulty: "easy",
        estimatedTime: "5 hours",
        resourceLink: "https://youtube.com/watch?v=html-css-2024",
        resourceTitle: "Modern CSS Complete Guide",
        proofOfWork: "Clone a popular landing page (Stripe/Linear) with perfect responsiveness",
        completed: false,
        week: 1,
        day: 1,
      },
      {
        id: "1-2",
        title: "JavaScript Fundamentals",
        description: "Master ES6+ features, async/await, and DOM manipulation",
        difficulty: "medium",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=js-fundamentals",
        resourceTitle: "JavaScript Deep Dive",
        proofOfWork: "Build an interactive todo app with local storage persistence",
        completed: false,
        week: 1,
        day: 3,
      },
      {
        id: "1-3",
        title: "React Essentials",
        description: "Learn React components, hooks, and state management",
        difficulty: "medium",
        estimatedTime: "8 hours",
        resourceLink: "https://youtube.com/watch?v=react-2024",
        resourceTitle: "React Complete Course",
        proofOfWork: "Convert your todo app to React with proper component structure",
        completed: false,
        week: 1,
        day: 5,
      },
      // Week 2
      {
        id: "2-1",
        title: "TypeScript for React",
        description: "Add type safety to your React applications",
        difficulty: "medium",
        estimatedTime: "4 hours",
        resourceLink: "https://youtube.com/watch?v=typescript-react",
        resourceTitle: "TypeScript with React",
        proofOfWork: "Migrate your React app to TypeScript with 100% type coverage",
        completed: false,
        week: 2,
        day: 1,
      },
      {
        id: "2-2",
        title: "Node.js & Express",
        description: "Build REST APIs with Node.js and Express framework",
        difficulty: "medium",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=nodejs-api",
        resourceTitle: "Node.js API Tutorial",
        proofOfWork: "Build a REST API with CRUD operations and proper error handling",
        completed: false,
        week: 2,
        day: 3,
      },
      {
        id: "2-3",
        title: "PostgreSQL & Prisma",
        description: "Learn database design and ORM usage",
        difficulty: "medium",
        estimatedTime: "5 hours",
        resourceLink: "https://youtube.com/watch?v=prisma-postgres",
        resourceTitle: "Prisma Complete Guide",
        proofOfWork: "Design and implement a database schema for an e-commerce app",
        completed: false,
        week: 2,
        day: 5,
      },
      // Week 3
      {
        id: "3-1",
        title: "Authentication & Security",
        description: "Implement JWT auth, OAuth, and security best practices",
        difficulty: "hard",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=auth-security",
        resourceTitle: "Web Security Guide",
        proofOfWork: "Add authentication to your API with protected routes",
        completed: false,
        week: 3,
        day: 1,
      },
      {
        id: "3-2",
        title: "Full Stack Project",
        description: "Build a complete full-stack application from scratch",
        difficulty: "hard",
        estimatedTime: "10 hours",
        resourceLink: "https://youtube.com/watch?v=fullstack-project",
        resourceTitle: "Full Stack Build",
        proofOfWork: "Build and deploy a complete project management app",
        completed: false,
        week: 3,
        day: 3,
      },
      // Week 4
      {
        id: "4-1",
        title: "CI/CD & Deployment",
        description: "Set up automated deployments with GitHub Actions",
        difficulty: "medium",
        estimatedTime: "4 hours",
        resourceLink: "https://youtube.com/watch?v=cicd-deploy",
        resourceTitle: "CI/CD Tutorial",
        proofOfWork: "Configure GitHub Actions for your project with tests and deployment",
        completed: false,
        week: 4,
        day: 1,
      },
      {
        id: "4-2",
        title: "System Design Basics",
        description: "Learn scalability, caching, and architecture patterns",
        difficulty: "hard",
        estimatedTime: "6 hours",
        resourceLink: "https://youtube.com/watch?v=system-design",
        resourceTitle: "System Design Interview",
        proofOfWork: "Write a design document for a URL shortener system",
        completed: false,
        week: 4,
        day: 3,
      },
    ],
  };

  // Default tasks if role not found
  return roleTasks[roleId] || roleTasks["fullstack-dev"];
};

const roleNames: Record<string, string> = {
  "ml-engineer": "ML Engineer",
  "fullstack-dev": "Full Stack Developer",
  "data-engineer": "Data Engineer",
  "devops-engineer": "DevOps Engineer",
  "security-engineer": "Security Engineer",
  "ai-product-manager": "AI Product Manager",
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [resumeName, setResumeName] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  useEffect(() => {
    // Get data from session storage
    const storedResume = sessionStorage.getItem("pivotpath_resume");
    const storedRole = sessionStorage.getItem("pivotpath_role");

    if (!storedResume || !storedRole) {
      // If no data, redirect to home after a short delay
      setTimeout(() => navigate("/"), 100);
      return;
    }

    setResumeName(storedResume);
    setSelectedRole(storedRole);

    // Simulate AI analysis loading
    setTimeout(() => {
      setTasks(generateSampleTasks(storedRole));
      setIsLoading(false);
    }, 1500);
  }, [navigate]);

  const handleToggleComplete = useCallback((taskId: string) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );
  }, []);

  const completedCount = tasks.filter((t) => t.completed).length;
  const totalCount = tasks.length;
  const readinessScore = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-24 px-4 flex flex-col items-center justify-center min-h-[80vh]">
          <div className="text-center space-y-6 animate-pulse">
            <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
              <Sparkles className="w-10 h-10 text-primary animate-pulse" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Analyzing Your Resume...</h2>
              <p className="text-muted-foreground">
                Our AI is mapping your skills to {roleNames[selectedRole || ""] || "your target role"}
              </p>
            </div>
            <div className="flex justify-center gap-2">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="w-3 h-3 rounded-full bg-primary animate-bounce"
                  style={{ animationDelay: `${i * 0.15}s` }}
                />
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20 pb-12 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="mb-8">
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
            
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Your 30-Day Roadmap
                </h1>
                <p className="text-muted-foreground">
                  Transitioning to{" "}
                  <span className="font-semibold text-primary">
                    {roleNames[selectedRole || ""] || "Tech Role"}
                  </span>{" "}
                  • Based on {resumeName}
                </p>
              </div>
              
              <Button
                onClick={() => {
                  sessionStorage.clear();
                  navigate("/");
                }}
                variant="outline"
              >
                Start Over
              </Button>
            </div>
          </div>

          {/* Main content grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Roadmap Timeline - Main content */}
            <div className="lg:col-span-2 order-2 lg:order-1">
              <RoadmapTimeline tasks={tasks} onToggleComplete={handleToggleComplete} />
            </div>

            {/* Sidebar - Progress & Share */}
            <div className="lg:col-span-1 order-1 lg:order-2 space-y-6">
              {/* Progress Gauge Card */}
              <div className="glass-card rounded-2xl p-6 text-center sticky top-24">
                <h3 className="font-semibold text-foreground mb-4">Job Readiness Meter</h3>
                <ProgressGauge percentage={readinessScore} />
                <p className="text-sm text-muted-foreground mt-4">
                  {completedCount} of {totalCount} tasks completed
                </p>
                
                {readinessScore >= 80 && (
                  <div className="mt-4 p-3 rounded-lg bg-success/10 border border-success/20">
                    <p className="text-sm font-medium text-success">
                      🎉 You're interview ready!
                    </p>
                  </div>
                )}
              </div>

              {/* LinkedIn Share Kit */}
              <LinkedInShareKit
                readinessScore={readinessScore}
                targetRole={roleNames[selectedRole || ""] || "Tech Role"}
                completedTasks={completedCount}
                totalTasks={totalCount}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;