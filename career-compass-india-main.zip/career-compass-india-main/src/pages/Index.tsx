import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { TargetRoleSelector } from "@/components/TargetRoleSelector";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [showRoleSelector, setShowRoleSelector] = useState(false);

  const handleFileUpload = useCallback((file: File) => {
    setUploadedFile(file);
    setShowRoleSelector(true);
    // Scroll to role selector
    setTimeout(() => {
      document.getElementById("role-selector")?.scrollIntoView({ behavior: "smooth" });
    }, 300);
  }, []);

  const handleGetStarted = () => {
    if (uploadedFile && selectedRole) {
      // Store in sessionStorage for demo purposes
      sessionStorage.setItem("pivotpath_resume", uploadedFile.name);
      sessionStorage.setItem("pivotpath_role", selectedRole);
      navigate("/dashboard");
    } else if (!uploadedFile) {
      // Scroll to dropzone
      document.querySelector(".dropzone")?.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-16">
        <HeroSection onFileUpload={handleFileUpload} onGetStarted={handleGetStarted} />

        {/* Role Selector Section */}
        {showRoleSelector && (
          <section id="role-selector" className="py-16 px-4 bg-secondary/30 animate-fade-in">
            <div className="container mx-auto max-w-4xl space-y-8">
              {/* Progress indicator */}
              <div className="flex items-center justify-center gap-4 mb-8">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-success flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-success-foreground" />
                  </div>
                  <span className="text-sm font-medium text-foreground">Resume Uploaded</span>
                </div>
                <div className="w-12 h-0.5 bg-border" />
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                    selectedRole ? "bg-success text-success-foreground" : "bg-primary text-primary-foreground"
                  }`}>
                    2
                  </div>
                  <span className="text-sm font-medium text-foreground">Select Role</span>
                </div>
                <div className="w-12 h-0.5 bg-border" />
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-sm text-muted-foreground">
                    3
                  </div>
                  <span className="text-sm font-medium text-muted-foreground">Get Roadmap</span>
                </div>
              </div>

              <TargetRoleSelector selectedRole={selectedRole} onSelectRole={setSelectedRole} />

              {selectedRole && (
                <div className="flex justify-center pt-6 animate-fade-in">
                  <Button
                    onClick={handleGetStarted}
                    size="lg"
                    className="btn-gradient text-primary-foreground border-0 px-8 py-6 text-lg font-semibold gap-2"
                  >
                    Generate My Roadmap
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </div>
              )}
            </div>
          </section>
        )}

        {/* Features Section */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-5xl">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Why PivotPath Works
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Built specifically for the Indian tech job market in 2026
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  emoji: "🎯",
                  title: "AI Skill Mapping",
                  description: "Our AI analyzes your resume and identifies transferable skills for tech roles",
                },
                {
                  emoji: "📚",
                  title: "Curated Resources",
                  description: "Hand-picked YouTube tutorials, docs, and courses optimized for low-bandwidth",
                },
                {
                  emoji: "🏆",
                  title: "Proof of Work",
                  description: "Each task has a mini-project to build your portfolio and prove your skills",
                },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="glass-card rounded-2xl p-6 text-center hover:shadow-glow transition-shadow"
                >
                  <div className="text-4xl mb-4">{feature.emoji}</div>
                  <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 px-4 border-t border-border">
          <div className="container mx-auto text-center">
            <p className="text-sm text-muted-foreground">
              © 2026 PivotPath India. Skills over Degrees. Built for Bharat 🇮🇳
            </p>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default Index;