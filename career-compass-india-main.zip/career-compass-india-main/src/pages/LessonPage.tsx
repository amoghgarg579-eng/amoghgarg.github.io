import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { LessonQuiz } from "@/components/LessonQuiz";
import { AITutorChat } from "@/components/AITutorChat";
import { getLessonContent, getPlaceholderLesson, LessonContent } from "@/data/lessonContent";
import { Task } from "@/components/TaskCard";
import { 
  ArrowLeft, 
  BookOpen, 
  CheckCircle2, 
  Download, 
  FileText, 
  ListChecks, 
  Lock,
  ClipboardList,
  Trophy
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const LessonPage = () => {
  const { taskId } = useParams<{ taskId: string }>();
  const navigate = useNavigate();
  const [lesson, setLesson] = useState<LessonContent | null>(null);
  const [quizPassed, setQuizPassed] = useState(false);
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [activeTab, setActiveTab] = useState("content");

  useEffect(() => {
    if (!taskId) {
      navigate("/dashboard");
      return;
    }

    // Try to get custom lesson content
    const customLesson = getLessonContent(taskId);
    
    if (customLesson) {
      setLesson(customLesson);
    } else {
      // Get task info from session storage and create placeholder
      const storedRole = sessionStorage.getItem("pivotpath_role");
      // For now, create a generic placeholder
      setLesson(getPlaceholderLesson({
        id: taskId,
        title: `Lesson ${taskId}`,
        description: "This lesson content is being developed.",
        proofOfWork: "Complete the assignment as described."
      }));
    }

    // Load quiz completion state from session storage
    const quizState = sessionStorage.getItem(`quiz_${taskId}`);
    if (quizState) {
      const parsed = JSON.parse(quizState);
      setQuizPassed(parsed.passed);
      setQuizScore(parsed.score);
    }

    // Load completed steps
    const stepsState = sessionStorage.getItem(`steps_${taskId}`);
    if (stepsState) {
      setCompletedSteps(new Set(JSON.parse(stepsState)));
    }
  }, [taskId, navigate]);

  const handleQuizComplete = (passed: boolean, score: number) => {
    setQuizPassed(passed);
    setQuizScore(score);
    // Save to session storage
    sessionStorage.setItem(`quiz_${taskId}`, JSON.stringify({ passed, score }));
  };

  const toggleStep = (stepIndex: number) => {
    setCompletedSteps(prev => {
      const newSet = new Set(prev);
      if (newSet.has(stepIndex)) {
        newSet.delete(stepIndex);
      } else {
        newSet.add(stepIndex);
      }
      // Save to session storage
      sessionStorage.setItem(`steps_${taskId}`, JSON.stringify([...newSet]));
      return newSet;
    });
  };

  if (!lesson) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-24 px-4 flex items-center justify-center">
          <p className="text-muted-foreground">Loading lesson...</p>
        </main>
      </div>
    );
  }

  const allStepsCompleted = completedSteps.size === lesson.proofOfWorkSteps.length;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20 pb-12 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Back button */}
          <button
            onClick={() => navigate("/dashboard")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Roadmap
          </button>

          {/* Lesson Header */}
          <div className="glass-card rounded-2xl p-6 md:p-8 mb-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
                  {lesson.title}
                </h1>
                <p className="text-muted-foreground leading-relaxed">
                  {lesson.introduction}
                </p>
              </div>
            </div>

            {/* Progress badges */}
            <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-border">
              <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm ${
                allStepsCompleted ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
              }`}>
                <ListChecks className="w-4 h-4" />
                {completedSteps.size}/{lesson.proofOfWorkSteps.length} Steps
              </div>
              
              <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm ${
                quizPassed ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"
              }`}>
                {quizPassed ? (
                  <>
                    <Trophy className="w-4 h-4" />
                    Quiz Passed ({quizScore}%)
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    Quiz Pending
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Tabbed Content */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 h-auto p-1">
              <TabsTrigger value="content" className="py-2.5">
                <BookOpen className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Learn</span>
              </TabsTrigger>
              <TabsTrigger value="practice" className="py-2.5">
                <ClipboardList className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Practice</span>
              </TabsTrigger>
              <TabsTrigger value="quiz" className="py-2.5">
                <Trophy className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Quiz</span>
              </TabsTrigger>
              <TabsTrigger value="resources" className="py-2.5">
                <Download className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Resources</span>
              </TabsTrigger>
            </TabsList>

            {/* Learn Tab */}
            <TabsContent value="content" className="space-y-6">
              {lesson.sections.map((section, index) => (
                <div key={index} className="glass-card rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    {section.heading}
                  </h3>
                  <div className="prose prose-sm max-w-none text-foreground/90">
                    {section.content.split('\n\n').map((paragraph, pIndex) => (
                      <div key={pIndex} className="mb-4 last:mb-0">
                        {paragraph.includes('```') ? (
                          <pre className="bg-muted/50 rounded-lg p-4 overflow-x-auto text-sm font-mono">
                            <code>{paragraph.replace(/```\w*\n?/g, '').trim()}</code>
                          </pre>
                        ) : (
                          <p className="whitespace-pre-wrap leading-relaxed">
                            {paragraph.split(/(\*\*.*?\*\*)/g).map((part, i) => {
                              if (part.startsWith('**') && part.endsWith('**')) {
                                return <strong key={i}>{part.slice(2, -2)}</strong>;
                              }
                              return part;
                            })}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              <div className="flex justify-end">
                <Button onClick={() => setActiveTab("practice")}>
                  Continue to Practice
                  <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
                </Button>
              </div>
            </TabsContent>

            {/* Practice Tab - Proof of Work */}
            <TabsContent value="practice">
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
                    <ClipboardList className="w-5 h-5 text-accent-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Proof of Work Assignment</h3>
                    <p className="text-sm text-muted-foreground">
                      Complete these steps to demonstrate mastery
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  {lesson.proofOfWorkSteps.map((step, index) => (
                    <button
                      key={index}
                      onClick={() => toggleStep(index)}
                      className={`w-full flex items-start gap-3 p-4 rounded-lg border transition-all text-left ${
                        completedSteps.has(index)
                          ? "border-success bg-success/5"
                          : "border-border bg-background hover:border-primary/50"
                      }`}
                    >
                      <div className="mt-0.5 flex-shrink-0">
                        {completedSteps.has(index) ? (
                          <CheckCircle2 className="w-5 h-5 text-success" />
                        ) : (
                          <div className="w-5 h-5 rounded-full border-2 border-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-medium text-muted-foreground">
                          Step {index + 1}
                        </span>
                        <p className={`text-foreground ${
                          completedSteps.has(index) ? "line-through text-muted-foreground" : ""
                        }`}>
                          {step}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>

                {allStepsCompleted && (
                  <div className="mt-6 p-4 rounded-lg bg-success/10 border border-success/20">
                    <p className="text-sm font-medium text-success flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5" />
                      All steps completed! Now take the quiz to unlock the next lesson.
                    </p>
                  </div>
                )}

                <div className="flex justify-end mt-6">
                  <Button onClick={() => setActiveTab("quiz")}>
                    Take Quiz
                    <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* Quiz Tab */}
            <TabsContent value="quiz">
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Trophy className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Knowledge Check</h3>
                    <p className="text-sm text-muted-foreground">
                      Score 67% or higher to unlock the next lesson
                    </p>
                  </div>
                </div>

                <LessonQuiz
                  questions={lesson.quiz}
                  onComplete={handleQuizComplete}
                  lessonTitle={lesson.title}
                  lessonContent={lesson.sections.map(s => `${s.heading}\n${s.content}`).join('\n\n')}
                />
              </div>
            </TabsContent>

            {/* Resources Tab */}
            <TabsContent value="resources">
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
                    <FileText className="w-5 h-5 text-accent-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Downloadable Resources</h3>
                    <p className="text-sm text-muted-foreground">
                      PDFs, templates, and cheat sheets for this lesson
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  {lesson.resources.map((resource) => (
                    <div
                      key={resource.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-border bg-background hover:border-primary/50 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          resource.type === "pdf" 
                            ? "bg-destructive/10 text-destructive" 
                            : resource.type === "template"
                            ? "bg-primary/10 text-primary"
                            : "bg-success/10 text-success"
                        }`}>
                          {resource.type === "pdf" ? (
                            <FileText className="w-5 h-5" />
                          ) : resource.type === "template" ? (
                            <FileText className="w-5 h-5" />
                          ) : (
                            <ListChecks className="w-5 h-5" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{resource.title}</p>
                          <p className="text-sm text-muted-foreground">{resource.description}</p>
                        </div>
                      </div>
                      
                      <Button variant="outline" size="sm" disabled>
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  ))}
                </div>

                <p className="text-xs text-muted-foreground mt-4 text-center">
                  Resources are placeholders. Upload your own PDFs and templates to enable downloads.
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* AI Tutor Chatbot */}
      <AITutorChat 
        lessonTitle={lesson.title}
        lessonContext={lesson.sections.map(s => `${s.heading}\n${s.content}`).join('\n\n')}
      />
    </div>
  );
};

export default LessonPage;
