export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // index of correct option
  explanation?: string; // optional explanation for the correct answer
}

export interface LessonResource {
  id: string;
  title: string;
  type: "pdf" | "template" | "cheatsheet";
  description: string;
  downloadUrl?: string; // placeholder for now
}

export interface LessonContent {
  taskId: string;
  title: string;
  introduction: string;
  sections: {
    heading: string;
    content: string;
  }[];
  proofOfWorkSteps: string[];
  quiz: QuizQuestion[];
  resources: LessonResource[];
}

// Sample lesson content - in production this would come from a CMS or database
export const lessonContentMap: Record<string, LessonContent> = {
  "1-1": {
    taskId: "1-1",
    title: "Python Fundamentals Refresher",
    introduction: `Python is the backbone of Machine Learning. Before diving into complex algorithms and frameworks, you need a rock-solid foundation in Python's core concepts. This lesson will take you from basics to confident Python programmer, focusing specifically on the patterns and structures used heavily in ML codebases.`,
    sections: [
      {
        heading: "Why Python for Machine Learning?",
        content: `Python dominates the ML landscape for several reasons:

**Readability & Simplicity**: Python's clean syntax allows data scientists to focus on solving problems rather than fighting with complex language features.

**Rich Ecosystem**: Libraries like NumPy, Pandas, Scikit-learn, TensorFlow, and PyTorch form a complete ML toolkit.

**Community Support**: Millions of developers, thousands of tutorials, and active forums mean help is always available.

**Industry Standard**: Companies like Google, Meta, and OpenAI use Python for their ML infrastructure.`
      },
      {
        heading: "Essential Data Structures",
        content: `**Lists**: Ordered, mutable collections. Perfect for storing sequences of data.
\`\`\`python
scores = [85, 92, 78, 96, 88]
scores.append(90)  # Add element
average = sum(scores) / len(scores)
\`\`\`

**Dictionaries**: Key-value pairs for fast lookups.
\`\`\`python
model_config = {
    "learning_rate": 0.001,
    "epochs": 100,
    "batch_size": 32
}
\`\`\`

**Tuples**: Immutable sequences, great for fixed data.
\`\`\`python
image_shape = (224, 224, 3)  # height, width, channels
\`\`\`

**Sets**: Unique elements, perfect for deduplication.
\`\`\`python
unique_labels = set(predictions)
\`\`\``
      },
      {
        heading: "Functions and Lambda Expressions",
        content: `Functions are the building blocks of reusable code:

\`\`\`python
def calculate_accuracy(predictions, labels):
    """Calculate classification accuracy."""
    correct = sum(p == l for p, l in zip(predictions, labels))
    return correct / len(labels)
\`\`\`

**Lambda functions** for quick, inline operations:
\`\`\`python
# Normalize a list of values
normalize = lambda x: (x - min(x)) / (max(x) - min(x))

# Sort by custom key
sorted_models = sorted(models, key=lambda m: m['accuracy'], reverse=True)
\`\`\``
      },
      {
        heading: "Object-Oriented Programming for ML",
        content: `Classes help organize complex ML code:

\`\`\`python
class DataPreprocessor:
    def __init__(self, normalize=True, fill_na='mean'):
        self.normalize = normalize
        self.fill_na = fill_na
        self.stats = {}
    
    def fit(self, data):
        """Learn statistics from training data."""
        self.stats['mean'] = data.mean()
        self.stats['std'] = data.std()
        return self
    
    def transform(self, data):
        """Apply learned transformations."""
        if self.normalize:
            return (data - self.stats['mean']) / self.stats['std']
        return data
\`\`\`

This pattern mirrors how Scikit-learn's transformers work!`
      }
    ],
    proofOfWorkSteps: [
      "Create a new Python file called `csv_analyzer.py`",
      "Write a function `load_csv(filepath)` that reads a CSV file and returns a list of dictionaries",
      "Implement `calculate_statistics(data, column)` that returns mean, median, and mode for a numeric column",
      "Add `filter_data(data, column, condition)` that filters rows based on a lambda condition",
      "Create a `main()` function that processes a sample CSV and prints a summary report",
      "Test with a sample dataset (you can create a simple one with 10-20 rows)",
      "Bonus: Add error handling for missing files or invalid columns"
    ],
    quiz: [
      {
        id: "q1",
        question: "Which Python data structure would be best for storing model hyperparameters with their names?",
        options: [
          "List - because it maintains order",
          "Dictionary - because it maps names to values",
          "Tuple - because hyperparameters shouldn't change",
          "Set - because each hyperparameter is unique"
        ],
        correctAnswer: 1
      },
      {
        id: "q2",
        question: "What is the primary advantage of using a class with fit() and transform() methods in ML?",
        options: [
          "It makes the code look more professional",
          "It allows learning from training data and applying to new data consistently",
          "Classes run faster than functions",
          "It's required by all ML libraries"
        ],
        correctAnswer: 1
      },
      {
        id: "q3",
        question: "What will `[x**2 for x in range(5) if x % 2 == 0]` return?",
        options: [
          "[0, 1, 4, 9, 16]",
          "[0, 4, 16]",
          "[1, 9]",
          "[0, 2, 4]"
        ],
        correctAnswer: 1
      }
    ],
    resources: [
      {
        id: "r1",
        title: "Python for ML Cheat Sheet",
        type: "cheatsheet",
        description: "Quick reference for Python syntax commonly used in ML projects"
      },
      {
        id: "r2",
        title: "Sample CSV Dataset",
        type: "template",
        description: "A sample dataset to practice your CSV analyzer assignment"
      }
    ]
  },
  "1-2": {
    taskId: "1-2",
    title: "NumPy & Pandas Deep Dive",
    introduction: `NumPy and Pandas are the twin pillars of data manipulation in Python. NumPy provides fast numerical operations on arrays, while Pandas offers intuitive data structures for real-world datasets. Mastering these libraries is non-negotiable for any ML practitioner.`,
    sections: [
      {
        heading: "NumPy: The Foundation of Numerical Computing",
        content: `NumPy arrays are the backbone of ML computations:

**Creating Arrays**:
\`\`\`python
import numpy as np

# From lists
arr = np.array([1, 2, 3, 4, 5])

# Zeros and ones
zeros = np.zeros((3, 4))  # 3x4 matrix of zeros
ones = np.ones((2, 3))    # 2x3 matrix of ones

# Random arrays
random_uniform = np.random.rand(100, 10)  # Uniform [0,1)
random_normal = np.random.randn(100, 10)  # Standard normal
\`\`\`

**Why NumPy is Fast**: NumPy operations are vectorized - they operate on entire arrays at once using optimized C code, avoiding slow Python loops.`
      },
      {
        heading: "Essential NumPy Operations for ML",
        content: `**Broadcasting**: Automatically expands arrays for element-wise operations
\`\`\`python
# Normalize each column
data = np.random.rand(100, 5)
normalized = (data - data.mean(axis=0)) / data.std(axis=0)
\`\`\`

**Matrix Operations**:
\`\`\`python
# Dot product (essential for neural networks)
weights = np.random.randn(10, 5)
inputs = np.random.randn(5)
output = np.dot(weights, inputs)

# Matrix multiplication
A = np.random.randn(3, 4)
B = np.random.randn(4, 2)
C = A @ B  # 3x2 result
\`\`\`

**Reshaping**: Critical for preparing data for models
\`\`\`python
# Flatten an image
image = np.random.rand(28, 28)
flat = image.reshape(-1)  # Shape: (784,)

# Batch of images
images = np.random.rand(100, 28, 28)
flat_batch = images.reshape(100, -1)  # Shape: (100, 784)
\`\`\``
      },
      {
        heading: "Pandas: DataFrames for Real-World Data",
        content: `Pandas makes working with tabular data intuitive:

**Creating DataFrames**:
\`\`\`python
import pandas as pd

df = pd.DataFrame({
    'name': ['Alice', 'Bob', 'Charlie'],
    'age': [25, 30, 35],
    'salary': [50000, 60000, 75000]
})

# From CSV
df = pd.read_csv('data.csv')
\`\`\`

**Selection and Filtering**:
\`\`\`python
# Column selection
ages = df['age']
subset = df[['name', 'salary']]

# Filtering
high_earners = df[df['salary'] > 55000]
young_high_earners = df[(df['age'] < 30) & (df['salary'] > 50000)]
\`\`\``
      },
      {
        heading: "Data Cleaning and Transformation",
        content: `Real-world data is messy. Pandas helps you clean it:

**Handling Missing Values**:
\`\`\`python
# Check for nulls
df.isnull().sum()

# Fill missing values
df['age'].fillna(df['age'].mean(), inplace=True)

# Drop rows with missing values
df_clean = df.dropna()
\`\`\`

**Feature Engineering**:
\`\`\`python
# Create new features
df['salary_per_year'] = df['salary'] / df['experience_years']

# One-hot encoding
df_encoded = pd.get_dummies(df, columns=['category'])

# Binning continuous variables
df['age_group'] = pd.cut(df['age'], bins=[0, 25, 35, 50, 100], 
                         labels=['Young', 'Adult', 'Middle', 'Senior'])
\`\`\``
      }
    ],
    proofOfWorkSteps: [
      "Download the Kaggle 'Titanic' dataset (or use any CSV with 500+ rows)",
      "Load the data using Pandas and display basic info (shape, dtypes, head)",
      "Calculate and print: survival rate, average age, class distribution",
      "Handle missing values in 'Age' column using median imputation",
      "Create a new feature 'FamilySize' = SibSp + Parch + 1",
      "Use groupby to find survival rate by passenger class",
      "Export your cleaned dataset to a new CSV file",
      "Document 5 interesting insights you discovered in a markdown file"
    ],
    quiz: [
      {
        id: "q1",
        question: "What does `np.random.randn(100, 10)` create?",
        options: [
          "100 random integers between 0 and 10",
          "A 100x10 matrix with values from standard normal distribution",
          "A 100x10 matrix with values between 0 and 1",
          "10 arrays each with 100 random values"
        ],
        correctAnswer: 1
      },
      {
        id: "q2",
        question: "How do you select rows where 'salary' > 50000 in Pandas?",
        options: [
          "df.select(salary > 50000)",
          "df.where('salary' > 50000)",
          "df[df['salary'] > 50000]",
          "df.filter(salary > 50000)"
        ],
        correctAnswer: 2
      },
      {
        id: "q3",
        question: "What is the result of `arr.reshape(-1)` on a 2D NumPy array?",
        options: [
          "It reverses the array",
          "It removes the last dimension",
          "It flattens the array into 1D",
          "It raises an error"
        ],
        correctAnswer: 2
      }
    ],
    resources: [
      {
        id: "r1",
        title: "NumPy Operations Cheat Sheet",
        type: "cheatsheet",
        description: "Essential NumPy operations for ML workflows"
      },
      {
        id: "r2",
        title: "Pandas Data Cleaning Template",
        type: "template",
        description: "Reusable notebook template for data preprocessing"
      },
      {
        id: "r3",
        title: "Sample Dataset Pack",
        type: "template",
        description: "3 practice datasets with varying complexity"
      }
    ]
  },
  "1-3": {
    taskId: "1-3",
    title: "Statistics for Machine Learning",
    introduction: `Statistics is the language of data science. Before you can build models that learn from data, you need to understand how to describe, visualize, and draw conclusions from data. This lesson covers the statistical foundations every ML engineer needs.`,
    sections: [
      {
        heading: "Descriptive Statistics: Summarizing Data",
        content: `**Measures of Central Tendency**:
- **Mean**: Average value, sensitive to outliers
- **Median**: Middle value, robust to outliers
- **Mode**: Most frequent value

\`\`\`python
import numpy as np
from scipy import stats

data = [23, 25, 28, 28, 29, 31, 150]  # Note the outlier

print(f"Mean: {np.mean(data):.2f}")      # 44.86 (skewed by outlier)
print(f"Median: {np.median(data):.2f}")  # 28.00 (unaffected)
print(f"Mode: {stats.mode(data)[0]}")    # 28 (most common)
\`\`\`

**When to use each**: Use median for income data (outliers), mean for symmetric distributions, mode for categorical data.`
      },
      {
        heading: "Probability Distributions",
        content: `**Normal (Gaussian) Distribution**: The bell curve, appears everywhere in nature.
\`\`\`python
from scipy.stats import norm
import matplotlib.pyplot as plt

# Generate normal distribution
x = np.linspace(-4, 4, 100)
y = norm.pdf(x, loc=0, scale=1)  # mean=0, std=1
\`\`\`

**Key Property**: ~68% within 1 std, ~95% within 2 std, ~99.7% within 3 std.

**Why it matters for ML**:
- Many algorithms assume normally distributed features
- Residuals in regression should be normal
- Central Limit Theorem: Sample means tend toward normal

**Other Important Distributions**:
- **Bernoulli**: Binary outcomes (click/no-click)
- **Poisson**: Count data (website visits per hour)
- **Uniform**: Equal probability (random initialization)`
      },
      {
        heading: "Hypothesis Testing: Making Data-Driven Decisions",
        content: `Hypothesis testing helps you determine if observed differences are real or due to chance.

**The Framework**:
1. **Null Hypothesis (H₀)**: No effect/difference exists
2. **Alternative Hypothesis (H₁)**: Effect/difference exists
3. **p-value**: Probability of seeing data this extreme if H₀ is true
4. **Significance Level (α)**: Threshold for rejecting H₀ (typically 0.05)

**Example: A/B Testing**
\`\`\`python
from scipy.stats import ttest_ind

# Conversion rates for two website versions
version_a = [0.12, 0.15, 0.11, 0.14, 0.13, 0.16, 0.12]
version_b = [0.18, 0.20, 0.17, 0.19, 0.21, 0.18, 0.19]

t_stat, p_value = ttest_ind(version_a, version_b)
print(f"p-value: {p_value:.4f}")

if p_value < 0.05:
    print("Significant difference! Version B is better.")
else:
    print("No significant difference detected.")
\`\`\``
      },
      {
        heading: "Correlation vs. Causation",
        content: `**Correlation** measures how two variables move together:
\`\`\`python
import pandas as pd

df = pd.DataFrame({
    'study_hours': [2, 4, 6, 8, 10],
    'test_score': [60, 70, 75, 85, 95]
})

correlation = df['study_hours'].corr(df['test_score'])
print(f"Correlation: {correlation:.2f}")  # Strong positive: ~0.98
\`\`\`

**Correlation coefficients**:
- +1: Perfect positive relationship
- 0: No linear relationship
- -1: Perfect negative relationship

**⚠️ Critical Warning**: Correlation ≠ Causation!
- Ice cream sales correlate with drowning deaths
- Both are caused by summer heat, not each other

**For ML**: Use correlation to identify features, but don't assume removing a correlated feature will change the target.`
      }
    ],
    proofOfWorkSteps: [
      "Find a dataset with at least 2 numerical columns (use Kaggle or create synthetic data)",
      "Calculate mean, median, and standard deviation for each numerical column",
      "Create a histogram to visualize the distribution of one variable",
      "Check if the data follows a normal distribution using a Q-Q plot or Shapiro-Wilk test",
      "Calculate correlation matrix between numerical features",
      "Formulate a hypothesis and perform a t-test or chi-square test",
      "Write a 1-page summary interpreting your statistical findings",
      "Identify any potential correlation vs. causation traps in your analysis"
    ],
    quiz: [
      {
        id: "q1",
        question: "A dataset has values [10, 12, 15, 15, 18, 200]. Which measure of central tendency is most appropriate?",
        options: [
          "Mean, because it uses all data points",
          "Median, because it's robust to the outlier (200)",
          "Mode, because 15 appears twice",
          "Standard deviation, because data is spread out"
        ],
        correctAnswer: 1
      },
      {
        id: "q2",
        question: "In hypothesis testing, what does a p-value of 0.03 mean?",
        options: [
          "There's a 3% chance the alternative hypothesis is true",
          "There's a 97% chance our result is correct",
          "If null hypothesis were true, we'd see data this extreme 3% of the time",
          "The effect size is 3%"
        ],
        correctAnswer: 2
      },
      {
        id: "q3",
        question: "Two variables have a correlation of 0.95. What can we conclude?",
        options: [
          "One variable causes the other",
          "They have a strong positive linear relationship",
          "Changing one will definitely change the other",
          "They share 95% of their data points"
        ],
        correctAnswer: 1
      }
    ],
    resources: [
      {
        id: "r1",
        title: "Statistics Formula Sheet",
        type: "cheatsheet",
        description: "All essential formulas for ML statistics in one page"
      },
      {
        id: "r2",
        title: "Hypothesis Testing Decision Tree",
        type: "template",
        description: "Flowchart to choose the right statistical test"
      }
    ]
  }
};

// Get lesson content by task ID, with fallback for tasks without custom content
export function getLessonContent(taskId: string): LessonContent | null {
  return lessonContentMap[taskId] || null;
}

// Generate placeholder lesson for tasks without custom content
export function getPlaceholderLesson(task: { id: string; title: string; description: string; proofOfWork: string }): LessonContent {
  return {
    taskId: task.id,
    title: task.title,
    introduction: task.description,
    sections: [
      {
        heading: "Overview",
        content: `This lesson will guide you through ${task.title.toLowerCase()}. Follow along with the content below and complete the proof of work assignment to master this skill.`
      },
      {
        heading: "Key Concepts",
        content: `This lesson is being developed. In the meantime, explore the topic independently and complete the proof of work assignment below.`
      }
    ],
    proofOfWorkSteps: task.proofOfWork.split('. ').filter(s => s.trim()),
    quiz: [
      {
        id: "placeholder-q1",
        question: `What is the main objective of ${task.title}?`,
        options: [
          "Understanding core concepts",
          "Building practical skills",
          "Both A and B",
          "None of the above"
        ],
        correctAnswer: 2
      },
      {
        id: "placeholder-q2",
        question: "Why is hands-on practice important in learning?",
        options: [
          "It reinforces theoretical knowledge",
          "It builds muscle memory",
          "It reveals gaps in understanding",
          "All of the above"
        ],
        correctAnswer: 3
      },
      {
        id: "placeholder-q3",
        question: "What should you do if you get stuck?",
        options: [
          "Give up immediately",
          "Search for solutions and ask for help",
          "Skip to the next lesson",
          "Wait for someone to help"
        ],
        correctAnswer: 1
      }
    ],
    resources: [
      {
        id: "placeholder-r1",
        title: "Learning Resources",
        type: "template",
        description: "Additional materials will be added soon"
      }
    ]
  };
}
